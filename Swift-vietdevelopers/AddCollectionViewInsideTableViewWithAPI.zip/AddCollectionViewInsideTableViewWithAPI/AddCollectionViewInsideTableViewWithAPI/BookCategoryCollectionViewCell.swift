//
//  BookCategoryCollectionViewCell.swift
//  AddCollectionViewInsideTableViewWithAPI
//
//  Created by chuottp on 28/09/2022.
//

import UIKit

class BookCategoryCollectionViewCell: UICollectionViewCell {

    
    @IBOutlet weak var lblBookPrice: UILabel!
    @IBOutlet weak var imgBookAvatar: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
